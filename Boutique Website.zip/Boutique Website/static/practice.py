def Adding (a,b,c):
    return (a+b/c)

Adding(2,8,5)
