def validation(prompt,low,high):
    while True:
        try:
            value=int(input(prompt))
            if low <=value<=high:
                return value
            else:
                print("value must be between", low, "and", high)
        except ValueError:
            print("Invalid Input(Integer)")


def Validation_float(prompt,low,high):
    while True:
        try:
            value=float(input(prompt))
            if low <= value <= high:
                return value
            else:
                print("Enter a value between", low, "and", high)
        except ValueError:
            print("Invalid Input(Enter a float value)")


Total_Miles = 0
Total_Gallons = 0

while True:
    Miles=validation("Enter Miles Driven(-1 to Quit): ", -1, 1000)
    if Miles == -1:
        break
    Gallons=Validation_float("Enter Gallons Used:  ",0.01,1000)
    MPG=Miles/Gallons
    print(f"Miles per Gallon for this flltank: {MPG:.2f}")


    Total_Miles += Miles
    Total_Gallons += Gallons

    if Total_Gallons > 0:
     Total_MPG= Total_Miles/Total_Gallons
    print(f"Total_Mpg: {Total_MPG:.2f}")
else:
    print("Can't Validate the data")



